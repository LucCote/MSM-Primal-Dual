.. _reference:

Reference
=========

.. autosummary::
   :toctree: reference/

   mpi4py.MPI
